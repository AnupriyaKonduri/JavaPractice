package day1Practice;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter two numbers:");
		int num1=s.nextInt();
		int num2=s.nextInt();
        System.out.println("Enter 1.Addition \n 2.Subtraction \n 3.Multiplication \n 4.Division");
		int choice=s.nextInt();
		switch(choice)
		{
		case 1:System.out.println("The addition of given numbers is:"+(num1+num2));
			break;
		case 2:System.out.println("The subtraction of given numbers is:"+(num1-num2));
			break;
		case 3:System.out.println("The multiplication of given numbers is:"+(num1*num2));
			break;
		case 4:System.out.println("The division of given numbers is:"+(num1/num2));
			break;
		default:System.out.println("You have entered the wrong choice");
			break;
		
		}
		
	}

}

package slm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PracticeProject6 
{

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/student";
    private static final String USER = "root";
    private static final String PASSWORD = "12345";
    public static void main(String[] args) 
    {
        Connection connection = null;
        try 
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            insertRecord(connection, "Konduri", 25);
            updateRecord(connection, 1, "Anupriya");
            deleteRecord(connection, 2);

        } 
        catch (ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
        } 
        finally 
        {
            try 
            {
                if (connection != null) 
                {
                    connection.close();
                }
            } 
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    private static void insertRecord(Connection connection, String name, int age) throws SQLException 
    {
        String insertSQL = "INSERT INTO students (name, age) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) 
        {
            preparedStatement.setString(1, name);
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " row(s) inserted.");
        }
    }

    private static void updateRecord(Connection connection, int id, String name) throws SQLException 
    {
        String updateSQL = "UPDATE student SET SNAME = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) 
        {
            preparedStatement.setString(1, name);
            preparedStatement.setInt(3, id);
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " row(s) updated.");
        }
    }

    private static void deleteRecord(Connection connection, int id) throws SQLException 
    {
        String deleteSQL = "DELETE FROM student WHERE SID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) 
        {
            preparedStatement.setInt(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " row(s) deleted.");
        }
    }
}


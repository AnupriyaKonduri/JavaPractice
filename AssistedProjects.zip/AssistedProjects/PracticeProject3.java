package slm;


	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;

	public class PracticeProject3 
	{
	    // JDBC URL, username, and password of MySQL server
	    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/teja25.student";
	    private static final String USER = "root";
	    private static final String PASSWORD = "12345";

	    public static void main(String[] args) 
	    {
	        Connection connection = null;
	        Statement statement = null;
	        ResultSet resultSet = null;

	        try 
	        {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
	            statement = connection.createStatement();
	            String sqlQuery = "SELECT SID,SNAME FROM teja25.student";
	            resultSet = statement.executeQuery(sqlQuery);
	            while (resultSet.next()) 
	            {
	                int id = resultSet.getInt("SID");
	                String name = resultSet.getString("SNAME");
	                System.out.println("SID: " + id + ", SName: " + name);
	            }
	        } 
	        catch (ClassNotFoundException | SQLException e) 
	        {
	            e.printStackTrace();
	        } 
	        finally 
	        {
	            try 
	            {
	                if (resultSet != null) resultSet.close();
	                if (statement != null) statement.close();
	                if (connection != null) connection.close();
	            } 
	            catch (SQLException e) 
	            {
	                e.printStackTrace();
	            }
	        }
	    }
	}
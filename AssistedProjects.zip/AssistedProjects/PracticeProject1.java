package slm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PracticeProject1
{
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/products";
    private static final String USER = "root";
    private static final String PASSWORD = "12345";
    private static Connection connection;
    private static PreparedStatement preparedStatement;
    private static ResultSet resultSet;
    public static void main(String[] args) 
    {
        try 
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            String sql = "SELECT * from products";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) 
            {
                int id = resultSet.getInt("product_id");
                String name = resultSet.getString("product_name");
                int price = resultSet.getInt("price");
                System.out.println("product_id: " + id + ", product_name: " + name + ", price: " + price);
            }
        }
        catch (SQLException | ClassNotFoundException e)
        {
            e.printStackTrace();
        } 
        finally
        {
            try 
            {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } 
            catch (SQLException e) 
            {
                e.printStackTrace();
            }
        }
    }
}
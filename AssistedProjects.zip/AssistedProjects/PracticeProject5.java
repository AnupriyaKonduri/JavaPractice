package slm;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;
	import java.sql.Statement;

	public class PracticeProject5 
	{
	    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/";
	    private static final String USER = "root";
	    private static final String PASSWORD = "12345";
	    // Database name for this example
	    private static final String DATABASE_NAME = "example_database";
	    public static void main(String[] args)
	    {
	        Connection connection = null;
	        Statement statement = null;

	        try 
	        {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
	            createDatabase(connection, DATABASE_NAME);
	            selectDatabase(connection, DATABASE_NAME);
	            dropDatabase(connection, DATABASE_NAME);

	        } 
	        catch (ClassNotFoundException | SQLException e) 
	        {
	            e.printStackTrace();
	        } 
	        finally
	        {
	            try 
	            {
	                if (statement != null)
	                {
	                    statement.close();
	                }
	                if (connection != null)
	                {
	                    connection.close();
	                }
	            } 
	            catch (SQLException e)
	            {
	                e.printStackTrace();
	            }
	        }
	    }

	    private static void createDatabase(Connection connection, String databaseName) throws SQLException 
	    {
	        Statement statement = connection.createStatement();
	        String createDatabaseSQL = "CREATE DATABASE IF NOT EXISTS " + databaseName;
	        statement.executeUpdate(createDatabaseSQL);
	        System.out.println("Database '" + databaseName + "' created successfully.");
	        statement.close();
	    }

	    private static void selectDatabase(Connection connection, String databaseName) throws SQLException 
	    {
	        Statement statement = connection.createStatement();
	        String useDatabaseSQL = "USE " + databaseName;
	        statement.executeUpdate(useDatabaseSQL);
	        System.out.println("Using database '" + databaseName + "'.");
	        statement.close();
	    }

	    private static void dropDatabase(Connection connection, String databaseName) throws SQLException
	    {
	        Statement statement = connection.createStatement();
	        String dropDatabaseSQL = "DROP DATABASE IF EXISTS " + databaseName;
	        statement.executeUpdate(dropDatabaseSQL);
	        System.out.println("Database '" + databaseName + "' dropped successfully.");
	        statement.close();
	    }
	}
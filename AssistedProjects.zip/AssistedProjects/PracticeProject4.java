package slm;

	import java.sql.*;

	public class PracticeProject4 
	{

	    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/student";
	    private static final String USER = "root";
	    private static final String PASSWORD = "12345";

	    public static void main(String[] args) 
	    {
	        Connection connection = null;
	        CallableStatement callableStatement = null;
	        ResultSet resultSet = null;

	        try 
	        {
	            
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
	            String storedProcedureCall = "{call getStudentById(?)}";
	            callableStatement = connection.prepareCall(storedProcedureCall);
	            int studentId = 1; 
	            callableStatement.setInt(1, studentId);
	            callableStatement.execute();
	            resultSet = callableStatement.getResultSet();
	            while (resultSet.next()) 
	            {
	                int id = resultSet.getInt("id");
	                String name = resultSet.getString("name");
	                System.out.println("ID: " + id + ", Name: " + name);
	            }
	        } 
	        catch (ClassNotFoundException | SQLException e)
	        {
	            e.printStackTrace(); 
	        } 
	        finally
	        {
	            try 
	            {
	                if (resultSet != null) resultSet.close();
	                if (callableStatement != null) callableStatement.close();
	                if (connection != null) connection.close();
	            } 
	            catch (SQLException e) 
	            {
	                e.printStackTrace();
	            }
	        }
	    }
	}
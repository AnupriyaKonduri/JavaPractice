package assistedPractice3;

import java.util.Scanner;

	public class PracticeProject4 
	{
	    public static void main(String[] args)
	    {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("Enter the number of rows for the first matrix:");
	        int rows1 = scanner.nextInt();
	        System.out.println("Enter the number of columns for the first matrix:");
	        int cols1 = scanner.nextInt();

	        System.out.println("Enter the number of rows for the second matrix:");
	        int rows2 = scanner.nextInt();
	        System.out.println("Enter the number of columns for the second matrix:");
	        int cols2 = scanner.nextInt();

	        if(cols1!=rows2) 
	        {
	            System.out.println("Matrix multiplication is not possible. Number of columns in the first matrix must be equal to the number of rows in the second matrix.");
	           
	        }

	        int[][] matrix1 = new int[rows1][cols1];
	        int[][] matrix2 = new int[rows2][cols2];

	        System.out.println("Enter elements of the first matrix:");
	        inputMatrix(matrix1, scanner);

	        System.out.println("Enter elements of the second matrix:");
	        inputMatrix(matrix2, scanner);

	        int[][] resultMatrix = multiplyMatrices(matrix1, matrix2);

	        System.out.println("Resultant Matrix after multiplication:");
	        printMatrix(resultMatrix);
	    }

	    public static void inputMatrix(int[][] matrix, Scanner scanner) 
	    {
	        for (int i = 0; i < matrix.length; i++) 
	        {
	            for (int j = 0; j < matrix[0].length; j++) 
	            {
	                matrix[i][j] = scanner.nextInt();
	            }
	        }
	    }

	    public static int[][] multiplyMatrices(int[][] matrix1, int[][] matrix2) 
	    {
	        int rows1 = matrix1.length;
	        int cols1 = matrix1[0].length;
	        int cols2 = matrix2[0].length;
	        int[][] resultMatrix = new int[rows1][cols2];
	        for (int i=0;i<rows1;i++) 
	        {
	            for (int j=0;j<cols2;j++) 
	            {
	                for (int k=0;k<cols1;k++) 
	                {
	                    resultMatrix[i][j] += matrix1[i][k]*matrix2[k][j];
	                }
	            }
	        }

	        return resultMatrix;
	    }

	    public static void printMatrix(int[][] matrix)
	    {
	        for (int i = 0; i < matrix.length; i++) 
	        {
	            for (int j = 0; j < matrix[0].length; j++) 
	            {
	                System.out.print(matrix[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }
	}
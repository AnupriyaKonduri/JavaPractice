package assistedPractice3;

import java.util.LinkedList;
import java.util.Queue;
public class PracticeProject9 
{
	    public static void main(String[] args)
	    {
	        Queue<Integer> queue = new LinkedList<>();
	        enqueueElement(queue, 10);
	        enqueueElement(queue, 2);
	        enqueueElement(queue, 30);
	        System.out.println("Queue after insertion: " + queue);
	        dequeueElement(queue);
	        dequeueElement(queue);
	        System.out.println("Queue after removal: " + queue);
	    }
	    private static void enqueueElement(Queue<Integer> queue, int element) 
	    {
	        System.out.println("Enqueuing element: " + element);
	        queue.offer(element);
	    }
	    private static void dequeueElement(Queue<Integer> queue)
	    {
	        if (!queue.isEmpty()) 
	        {
	            Integer removedElement = queue.poll();
	            System.out.println("Dequeued element: " + removedElement);
	        } 
	        else
	        {
	            System.out.println("Queue is empty. Cannot dequeue element.");
	        }
	    }
	}
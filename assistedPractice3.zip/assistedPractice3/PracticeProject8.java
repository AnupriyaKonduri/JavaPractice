package assistedPractice3;

import java.util.Stack;
public class PracticeProject8 
{
	    public static void main(String[] args) 
	    {
	        Stack<Integer> stack = new Stack<>();
	        pushElement(stack, 10);
	        pushElement(stack, 20);
	        pushElement(stack, 30);
	        pushElement(stack, 35);
	        pushElement(stack, 40);
	        pushElement(stack, 5);
	        System.out.println("Stack after insertion: " + stack);

	        popElement(stack);
	        popElement(stack);
	        System.out.println("Stack after removal: " + stack);
	    }
	    private static void pushElement(Stack<Integer> stack, int element)
	    {
	        System.out.println("Pushing element: " + element);
	        stack.push(element);
	    }

	    private static void popElement(Stack<Integer> stack) 
	    {
	        if (!stack.isEmpty()) 
	        {
	            Integer removedElement = stack.pop();
	            System.out.println("Popped element: " + removedElement);
	        } 
	        else 
	        {
	            System.out.println("Stack is empty. Cannot pop element.");
	        }
	    }
	}
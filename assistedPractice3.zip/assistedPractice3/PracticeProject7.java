package assistedPractice3;
 
class LinkedListExample 
{
    int data;
    LinkedListExample next;
    LinkedListExample prev;

    public LinkedListExample(int data) 
    {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList 
{
    private LinkedListExample head;
    public DoublyLinkedList() 
    {
        this.head = null;
    }
    public void insert(int data)
    {
    	LinkedListExample newNode = new LinkedListExample(data);
        if (head == null) 
        {
            head = newNode;
        } else 
        {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }

    public void traverseForward()
    {
        LinkedListExample current = head;
        System.out.println("Forward Traversal:");
        while (current!=null) 
        {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void traverseBackward() 
    {
    	LinkedListExample current=head;
        if (current==null)
        {
            System.out.println("List is empty.");
        }
        while (current.next!=null) 
        {
            current=current.next;
        }

        System.out.println("Backward Traversal:");
        while (current!=null)
        {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}

public class PracticeProject7 
{
    public static void main(String[] args)
    {
        DoublyLinkedList list = new DoublyLinkedList();
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);

        list.traverseForward();
        list.traverseBackward();
    }
}

package assistedPractice3;

class Node 
{
    int data;
    Node next;
    public Node(int data) 
    {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList 
{
    private Node head;
    public SinglyLinkedList() 
    {
        this.head = null;
    }
    public void insert(int data) 
    {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void deleteFirstOccurrence(int key)
    {
        if (head == null) 
        {
            System.out.println("List is empty. Nothing to delete.");
        }
        if (head.data == key) 
        {
            head = head.next;
            System.out.println("First occurrence of " + key + " deleted.");
        }

        Node current = head;
        Node prev = null;

        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }
        if (current == null) 
        {
            System.out.println("Key " + key + " not found in the list.");
            return;
        }
        prev.next = current.next;
        System.out.println("First occurrence of " + key + " deleted.");
    }

    public void display() 
    {
        Node current = head;
        while (current != null) 
        {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class PracticeProject5 
{
    public static void main(String[] args) 
    {
        SinglyLinkedList list = new SinglyLinkedList();
        list.insert(5);
        list.insert(10);
        list.insert(15);
        list.insert(20);
        list.insert(25);

        System.out.println("Original List:");
        list.display();

        list.deleteFirstOccurrence(15);
        System.out.println("List after deletion:");
        list.display();
    }
}

package assistedPractice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;

public class Practice_Project5 
{

	public static void main(String[] args) 
	{
		
		//ArrayList example
		ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");
        System.out.println("ArrayList Elements:");
        for (String fruit : arrayList)
        {
            System.out.println(fruit);
        }
        
     // HashSet example
        HashSet<Integer> hashSet = new HashSet<>();
        hashSet.add(10);
        hashSet.add(20);
        hashSet.add(30);
        System.out.println("\nHashSet Elements:");
        for (Integer number : hashSet)
        {
            System.out.println(number);
        }

        // HashMap example
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);
        System.out.println("\nHashMap Elements:");
        
        //Iterator example
        Iterator<String> keyIterator = hashMap.keySet().iterator();
        while (keyIterator.hasNext()) 
        {
            String key = keyIterator.next();
            System.out.println(key + ": " + hashMap.get(key));
        }
    }
}
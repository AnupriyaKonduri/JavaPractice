package assistedPractice;

public class Practice_Project1 {

	public static void main(String[] args) 
	{
		//Explicit type casting by using ()cast operator... data may lose 
		
		double d=23.456;
		int num=(int)d;
		System.out.println("The given double value is:"+num);
		
		//Implicit/widening type casting
		
		int num1=25;
		double value=num1;
		System.out.println("The given int value:"+value);
		
		
	}

}

package assistedPractice;

import java.util.Scanner;

public class Practice_Project9 
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of an array:");
		int size=s.nextInt();
		int[] arrayObject=new int[size];
		for(int i=0;i<size;i++)
		{
			arrayObject[i]=s.nextInt();
			System.out.println(arrayObject[i]);
		}
	}
}
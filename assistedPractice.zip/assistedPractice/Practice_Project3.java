package assistedPractice;

public class Practice_Project3 
{
	int a=30;
	int b=20;
	int sum=0;
	
	//1.Non-static method without return type and without arguments
	public void add()
	{
		sum=a+b;
		System.out.println("The sum of two numbers:"+sum);
	}
		
	//2.method without return type with arguments
	public void addition(int x,int y)
	{
		System.out.println("The addition of two numbwers:"+(x+y));
	}
	
	//3.method with return type without argument
	public int adding()
	{
		return a+b;
	}
	
	//4.method with return type and with argument
	public int sum(int num1,int num2)
	{
		return (num1+num2);
	}
	
	//5.static method
	public static void sub()
	{
		//creating object to access non-static members
		Practice_Project3 pp=new Practice_Project3();
		int sub=pp.a-pp.b;
		System.out.println("The subtraction of two numbers in static method:"+sub);
	}
	
	//main method
	public static void main(String[] args) 
	{
		Practice_Project3 pp3=new Practice_Project3();
		//calling method1
		pp3.add();
		
		//calling method2
		pp3.addition(2,3);
		
		//calling method3
		int method3=pp3.adding();
		System.out.println("Calling method with return type and no arguments:"+method3);
		
		//calling method4
		int method4=pp3.sum(40,50);
		System.out.println("calling method with returntype and arguments:"+method4);
		sub();
		
	}
}

package assistedPractice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Practice_Project10 {

	public static void main(String[] args)
	{
		String s="I am a good at 7pm";
		String regex="\\d";
		Pattern pattern=Pattern.compile(regex);
		Matcher matcher=pattern.matcher(s);
		
		int count=0;
		while(matcher.find())
		{
			System.out.printf("The matching found from %s to %s",(matcher.start()),(matcher.end()));
			count++;
		}

	}
}

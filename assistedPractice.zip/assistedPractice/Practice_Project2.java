package assistedPractice;

class OuterClass 
{
	    public int publicVar = 10;
	    private int privateVar = 20;
	    protected int protectedVar = 30;
	    int defaultVar = 40;
	    
	    class InnerClass 
	    {
	        // Accessing outer class members
	        public void accessOuterMembers() {
	            System.out.println("Accessing outer class members from InnerClass:");
	            System.out.println("publicVar: " + publicVar);
	            System.out.println("privateVar: " + privateVar);
	            System.out.println("protectedVar: " + protectedVar);
	            System.out.println("defaultVar: " + defaultVar);
	        }
	    }
}

class Practice_Project2
{
	    public static void main(String[] args) 
		{
	    	OuterClass  outerObject=new OuterClass ();
	    	 System.out.println("Accessing outer class members from main method:");
	         System.out.println("publicVar: " + outerObject.publicVar);
	         //System.out.println("privateVar: " + outerObject.privateVar);
	         System.out.println("protectedVar: " + outerObject.protectedVar);
	         System.out.println("defaultVar: " + outerObject.defaultVar);
	         
	         OuterClass.InnerClass innerObject = outerObject.new InnerClass();
	         innerObject.accessOuterMembers();
		}
}
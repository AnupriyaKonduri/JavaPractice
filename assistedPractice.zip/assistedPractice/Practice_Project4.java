package assistedPractice;

class Mainclass
{

		/*1.default constructor:When an object is created than jvm automatically calls the constructor*/
		
		//2.constructor without arguments
		public Mainclass()
		{
			System.out.println("This is the constructor without arguments");
		}
				
		//3.constructor with arguments
		public Mainclass(int num)
		{
			this();
			System.out.println("Constructor with argument:"+num);
		}
}

public class Practice_Project4 
{
	
		public static void main(String[] args) 
		{
			Mainclass mc=new Mainclass(10);
		}
}

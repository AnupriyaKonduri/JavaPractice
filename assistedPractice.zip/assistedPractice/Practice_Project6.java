package assistedPractice;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Practice_Project6 
{
	 public static void main(String[] args) 
	 {
	        // HashMap example
	        Map<String, Integer> hashMap = new HashMap<>();
	        hashMap.put("One", 1);
	        hashMap.put("Two", 2);
	        hashMap.put("Three", 3);

	        System.out.println("HashMap Elements:");
	        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) 
	        {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }

	        // TreeMap example
	        Map<String, Integer> treeMap = new TreeMap<>();
	        treeMap.put("Apple", 10);
	        treeMap.put("Banana", 5);
	        treeMap.put("Orange", 8);

	        System.out.println("\nTreeMap Elements:");
	        for (Map.Entry<String, Integer> entry : treeMap.entrySet())
	        {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }

	    }
}
package assistedPractice;

//outer class
public class Practice_Project7 
{
		    private int outerVariable = 10;
		    public Practice_Project7() 
		    {
		        System.out.println("OuterClass constructor");
		    }
		    
		    public void outerMethod() {
		        System.out.println("OuterClass method");
		    }

		    // Inner class
		    public class InnerClass 
		    {
		        private int innerVariable = 20;
		        public InnerClass() 
		        {
		            System.out.println("InnerClass constructor");
		        }
		        public void innerMethod() 
		        {
		            System.out.println("InnerClass method");
		            System.out.println("Accessing outerVariable from InnerClass: " + outerVariable);
		            outerMethod();
		        }
		    }

		    public static void main(String[] args)
		    {
		        // Creating object for the outer class
		    	Practice_Project7 outerObject = new Practice_Project7();

		        // Creating object for the inner class using the outer class 
		    	Practice_Project7.InnerClass innerObject = outerObject.new InnerClass();

		        // Calling methods of the inner class
		        innerObject.innerMethod();
		    }
}
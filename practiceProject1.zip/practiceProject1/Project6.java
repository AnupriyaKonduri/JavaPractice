package practiceProject1;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

	@WebServlet("/Project6")
	public class Project6 extends HttpServlet {
	    private static final long serialVersionUID = 1L;

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException 
	    {
	        HttpSession session = request.getSession(true);
	        String sessionId = session.getId();
	        Integer visitCount = (Integer) session.getAttribute("visitCount");
	        if (visitCount == null)
	        {
	            visitCount = 1;
	        } else 
	        {
	            visitCount++;
	        }
	        session.setAttribute("visitCount", visitCount);
	        String userId = null;
	        Cookie[] cookies = request.getCookies();
	        if (cookies != null) 
	        {
	            for (Cookie cookie : cookies) 
	            {
	                if ("userId".equals(cookie.getName()))
	                {
	                    userId = cookie.getValue();
	                    break;
	                }
	            }
	        }
	        if (userId == null) 
	        {
	            userId = "user" + System.currentTimeMillis();
	            Cookie userIdCookie = new Cookie("userId", userId);
	            userIdCookie.setMaxAge(365 * 24 * 60 * 60); 
	            response.addCookie(userIdCookie);
	        }

	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html>");
	        out.println("<head><title>Session Tracking with Cookies</title></head>");
	        out.println("<body>");
	        out.println("<h2>Session Tracking with Cookies</h2>");
	        out.println("<p>Session ID: " + sessionId + "</p>");
	        out.println("<p>User ID: " + userId + "</p>");
	        out.println("<p>Visit Count: " + visitCount + "</p>");
	        out.println("</body></html>");
	    }
	}

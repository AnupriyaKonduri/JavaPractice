package practiceProject1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("username") != null)
        {
            response.sendRedirect("WelcomeServlet");
        } 
        else 
        {
            showLoginForm(response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        if ("user123".equals(username) && "password123".equals(password)) 
        {
            HttpSession session = request.getSession(true);
            session.setAttribute("username", username);
            response.sendRedirect("Project2");
        } 
        else
        {
            showLoginFormWithErrorMessage(response, "Invalid username or password");
        }
    }

    private void showLoginForm(HttpServletResponse response) throws IOException 
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Login</title></head>");
        out.println("<body>");
        out.println("<h2>Login</h2>");
        out.println("<form action=\"LoginServlet\" method=\"post\">");
        out.println("  <label for=\"username\">Username:</label>");
        out.println("  <input type=\"text\" id=\"username\" name=\"username\" required><br>");
        out.println("  <label for=\"password\">Password:</label>");
        out.println("  <input type=\"password\" id=\"password\" name=\"password\" required><br>");
        out.println("  <input type=\"submit\" value=\"Login\">");
        out.println("</form>");
        out.println("</body></html>");
    }

    private void showLoginFormWithErrorMessage(HttpServletResponse response, String errorMessage) throws IOException 
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Login</title></head>");
        out.println("<body>");
        out.println("<h2>Login</h2>");
        out.println("<p style=\"color:red;\">" + errorMessage + "</p>");
        out.println("<form action=\"LoginServlet\" method=\"post\">");
        out.println("  <label for=\"username\">Username:</label>");
        out.println("  <input type=\"text\" id=\"username\" name=\"username\" required><br>");
        out.println("  <label for=\"password\">Password:</label>");
        out.println("  <input type=\"password\" id=\"password\" name=\"password\" required><br>");
        out.println("  <input type=\"submit\" value=\"Login\">");
        out.println("</form>");
        out.println("</body></html>");
    }
}

package practiceProject1;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Project8")
public class Project8 extends HttpServlet 
{
	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException
	    {
	        HttpSession session = request.getSession(true);
	        String sessionId = session.getId();
	        Integer visitCount = (Integer) session.getAttribute("visitCount");
	        if (visitCount == null) 
	        {
	            visitCount = 1;
	        } 
	        else 
	        {
	            visitCount++;
	        }
	        session.setAttribute("visitCount", visitCount);
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html>");
	        out.println("<head><title>Session Tracking with Hidden Form Fields</title></head>");
	        out.println("<body>");
	        out.println("<h2>Session Tracking with Hidden Form Fields</h2>");
	        out.println("<form action=\"Project8\" method=\"post\">");
	        out.println("  <input type=\"hidden\" name=\"sessionId\" value=\"" + sessionId + "\">");
	        out.println("  <p>Session ID: " + sessionId + "</p>");
	        out.println("  <p>Visit Count: " + visitCount + "</p>");
	        out.println("  <input type=\"submit\" value=\"Visit Again\">");
	        out.println("</form>");
	        out.println("</body></html>");
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException 
	    {
	        String sessionId = request.getParameter("sessionId");
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html>");
	        out.println("<head><title>Session Tracking with Hidden Form Fields</title></head>");
	        out.println("<body>");
	        out.println("<h2>Session Tracking with Hidden Form Fields</h2>");
	        out.println("<p>Session ID retrieved from the form: " + sessionId + "</p>");
	        out.println("</body></html>");
	    }
}	
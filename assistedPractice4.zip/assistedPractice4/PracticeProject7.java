package assistedPractice4;

public class PracticeProject7 
{
	    public static void mergeSort(int[] array) 
	    {
	        int n=array.length;

	        if (n>1) 
	        {
	            int mid=n/2;
	            int[] left=new int[mid];
	            int[] right=new int[n-mid];
	            System.arraycopy(array,0,left,0,mid);
	            System.arraycopy(array,mid,right,0,n-mid);
	            mergeSort(left);
	            mergeSort(right);
	            merge(array, left, right);
	        }
	    }

	    private static void merge(int[] array, int[] left, int[] right)
	    {
	        int nLeft=left.length;
	        int nRight=right.length;
	        int i=0, j=0, k=0;
	        while (i<nLeft&&j<nRight)
	        {
	            if (left[i]<=right[j]) 
	            {
	                array[k]=left[i];
	                i++;
	            } 
	            else 
	            {
	                array[k]=right[j];
	                j++;
	            }
	            k++;
	        }
	        while (i<nLeft) 
	        {
	            array[k]=left[i];
	            i++;
	            k++;
	        }
	        while (j<nRight) 
	        {
	            array[k]=right[j];
	            j++;
	            k++;
	        }
	    }

	    public static void main(String[] args)
	    {
	        int[] array={64,56,66,34,21,11};

	        System.out.println("Original array:");
	        printArray(array);

	        mergeSort(array);

	        System.out.println("\nSorted array:");
	        printArray(array);
	    }
	    private static void printArray(int[] array)
	    {
	        for (int i=0;i<array.length;i++)
	        {
	            System.out.print(array[i] + " ");
	        }
	        System.out.println();
	    }
	}
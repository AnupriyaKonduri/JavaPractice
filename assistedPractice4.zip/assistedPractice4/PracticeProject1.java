package assistedPractice4;

public class PracticeProject1 
{
	    public static int linearSearch(int[] array, int target)
	    {
	        for(int i=0;i<array.length;i++)
	        {
	            if(array[i]==target)
	            {
	                return i; // Element found, return its index
	            }
	        }
	        return -1; // Element not found
	    }

	    public static void main(String[] args)
	    {
	        int[] array={5,2,9,1,5,6};
	        int target=9;
	        int result=linearSearch(array,target);
	        if (result!=-1)
	        {
	            System.out.println("Element " + target + " found at index " + result);
	        } 
	        else 
	        {
	            System.out.println("Element " + target + " not found in the array");
	        }
	    }
	}